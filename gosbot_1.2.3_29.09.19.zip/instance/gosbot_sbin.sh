#!/bin/bash

cd /opt/gosbot/instance
php gosbot_sbin.php "$1" "$2" "$3" "$4" "$5"